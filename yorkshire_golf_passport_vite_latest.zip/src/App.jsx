import React from 'react'

export default function App(){
  return (
    <div style={{fontFamily:'system-ui, -apple-system, Segoe UI, Roboto, Arial', padding:24}}>
      <h1>Yorkshire Golf Passport</h1>
      <p>This export is ready for Vercel. The fuller demo is in your canvas session. I can repackage that version too if you want the full flow here.</p>
      <p>Next steps: npm install then npm run dev or drag this zip into Vercel New Project.</p>
    </div>
  )
}
