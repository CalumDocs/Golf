# Yorkshire Golf Passport Vite Demo

Local run
1. Install Node LTS
2. npm install
3. npm run dev

Build
1. npm run build
2. npm run preview

Deploy on Vercel
- New Project
- Drag and drop this folder or the zip
- Framework: React with Vite
- Build command: npm run build
- Output directory: dist
